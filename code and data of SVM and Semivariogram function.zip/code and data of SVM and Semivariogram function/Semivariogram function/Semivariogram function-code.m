% Initializtion parameter
clear all;
close all;
clc;
% Read the coordinates of two points (refer to "position" file)
fid=xlsread('C:2023\20230905132700-4.6n\position');%%%%%%%%%%%Read path (modified by path of researcher)
number_b=size(fid,1);

for ii=1:number_b
    step=ii
coordinate_a=fid(ii,:);
coordinate_b=fid;
% Calculate the separation distance between two points
distance_ab = [];
for i = 1:number_b
    %calculate the separation distance between station and epicentral
    distance_ab(i) = distance(coordinate_a(1),coordinate_a(2),coordinate_b(i,1),coordinate_b(i,2))/180*pi*6371;
end
distance_ab=distance_ab';
distance_ab_zong(:,ii)=distance_ab;
end
L=tril(distance_ab_zong);%% Calculate the separation distance between two points

%%
%Read the separation distance between two points (This is the result represented by "L" in the code, and we store the result in the "distance" file)
fid=xlsread('C:\Users\DELL\Desktop\distance');%%%%%%%%%%%%Read path (modified by path of researcher)
sort(fid);
max_fid=max(max(fid));
min_fid=min(min(fid));
m=2;          %%%%%%%%%%%%%%%set bin size
n=ceil(max_fid/m);   %%%%%%%number of data
for i=1:n
  a(i)=length(find(fid>m*i-m&fid<=m*i));
end
x=(m/2:m:m/2+(n-1)*m);
zong=[x;a]';

for i=1:50
    step=i
[ii,jj]=find(fid>m*i-m&fid<=m*i);
position=[ii,jj];
N=length(ii);
%Read PGA ("PGA" file)
PGA=xlsread('C:\Users\DELL\Desktop\PGA');%%%%%%%%%%%%Read path (modified by path of researcher)
%Read the correspoinding model of PGA ("model-PGA" file)
model_PGA=xlsread('C:\Users\DELL\Desktop\model-PGA');%%%%%%%%%%%%Read path (modified by path of researcher)
PGA_x=PGA(ii,1);  %%%%%%%%%%%%%%%%%%%%%%%%position of point 1
PGA_y=PGA(jj,1);  %%%%%%%%%%%%%%%%%%%%%%%%position of point 2
model_PGA_x=model_PGA(ii,1);
model_PGA_y=model_PGA(jj,1);
z_x=log(PGA_x)-log(model_PGA_x);
z_y=log(PGA_y)-log(model_PGA_y);
z=[z_x;z_y];
z=unique(z);
var_z=var(z);
y=(1/(2*N)*sum((z_x-z_y).^2))./var_z; %%%%%%%%%%%Semivariogram function
y_zong(i,:)=y; %%%%%%%%%%%Semivariogram function under different separation distances
end
